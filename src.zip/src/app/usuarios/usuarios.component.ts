// app/usuarios/usuarios.component.ts
import { Component, OnInit } from '@angular/core';
import { UsuarioService } from '../../services/usuario.service';

@Component({
  selector: 'app-usuarios',
  templateUrl: './usuarios.component.html',
  styleUrls: ['./usuarios.component.css']
})
export class UsuariosComponent implements OnInit {
  usuarios: any = [];

  constructor(private usuarioService: UsuarioService) {}

  ngOnInit(): void {
    this.fetchUsers();
  }

  fetchUsers() {
    this.usuarioService.fetchUser().subscribe(
      (data) => {
        this.usuarios = data;
        console.log('Usuarios obtenidos:', this.usuarios);
      },
      (error) => console.error('Error al obtener usuarios:', error)
    );
  }

  addUser() {
    const nuevoUsuario = { nombre: 'Jane', apellido: 'Smith' };
    this.usuarioService.postUser(nuevoUsuario).subscribe(
      (response) => {
        console.log('Usuario creado:', response);
        this.fetchUsers();
      },
      (error) => console.error('Error al crear usuario:', error)
    );
  }

  updateUser(id_usuario: string) {
    const usuarioActualizado = { nombre: 'Jane', apellido: 'Doe' };
    this.usuarioService.updateUser(id_usuario, usuarioActualizado).subscribe(
      (response) => {
        console.log('Usuario actualizado:', response);
        this.fetchUsers();
      },
      (error) => console.error('Error al actualizar usuario:', error)
    );
  }

  deleteUser(id_usuario: string) {
    this.usuarioService.deleteUser(id_usuario).subscribe(
      (response) => {
        console.log('Usuario eliminado:', response);
        this.fetchUsers();
      },
      (error) => console.error('Error al eliminar usuario:', error)
    );
  }
}
