import { Routes } from '@angular/router';
//import {UsersComponent} from './components/users/users.component' ;
import {UsersComponent} from './components/users/users.component' ;
import {InicioComponent} from './components/inicio/inicio.component' ;
import {ContenidoComponent} from './components/contenido/contenido.component' ;
import {RegistrosComponent} from './components/registros/registros.component' ;



export const routes: Routes = [
    {path:'usuario',component:UsersComponent},
    {path:'inicio',component:InicioComponent},
    {path:'contenido',component:ContenidoComponent},
    {path:'registros',component:RegistrosComponent}
];

