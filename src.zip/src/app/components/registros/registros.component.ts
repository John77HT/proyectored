import { Component, OnInit } from '@angular/core';
import { UsuarioService } from '../../services/usuario.service'; // Corregido el nombre del servicio
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-registros',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './registros.component.html',
  styleUrls: ['./registros.component.css']
})
export class RegistrosComponent implements OnInit {
  usuarios: any[] = [];
  usuarioEdit: any = null;

  constructor(private usuarioService: UsuarioService) {}

  ngOnInit(): void {
    this.obtenerUsuarios();
  }

  obtenerUsuarios() {
    this.usuarioService.fetchUser().subscribe(
      (res: any[]) => {  // Define res como un arreglo de usuarios
        this.usuarios = res;
      },
      (err) => {
        console.error('Error al obtener usuarios:', err);
      }
    );
  }

  actualizarUsuario() {
    if (this.usuarioEdit) {
      const id_usuario = this.usuarioEdit.id_usuario;
      console.log(`Actualizando usuario con ID: ${id_usuario}`, this.usuarioEdit);
      this.usuarioService.updateUser(id_usuario, this.usuarioEdit).subscribe(
        (res) => {
          console.log('Usuario actualizado:', res);
          this.usuarioEdit = null;
          this.obtenerUsuarios();
        },
        (err) => {
          console.error('Error al actualizar el usuario:', err);
        }
      );
    }
  }

  eliminarUsuario(id_usuario: string) {
    console.log(`Eliminando usuario con ID: ${id_usuario}`);
    this.usuarioService.deleteUser(id_usuario).subscribe(
      (res) => {
        console.log('Usuario eliminado:', res);
        this.obtenerUsuarios();
      },
      (err) => {
        console.error('Error al eliminar el usuario:', err);
      }
    );
  }

  seleccionarUsuario(usuario: any) {
    this.usuarioEdit = { ...usuario };
  }

  cancelarEdicion() {
    this.usuarioEdit = null;
  }
}
