import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UsuarioService {
  URL = 'http://localhost:3000/api/usuarios/';

  constructor(private http: HttpClient) {}

  // Especifica que retorna un Observable con un arreglo de usuarios
  fetchUser(): Observable<any[]> {
    return this.http.get<any[]>(this.URL);
  }

  postUser(user: any): Observable<any> {
    return this.http.post(this.URL, user);
  }

  updateUser(id_usuario: string, user: any): Observable<any> {
    return this.http.put(`${this.URL}${id_usuario}`, user);
  }

  deleteUser(id_usuario: string): Observable<any> {
    return this.http.delete(`${this.URL}${id_usuario}`);
  }
}
